source("RL4PRED/reward.R")

cmpStates <- function(state, state2) {
	res = FALSE
	if (isTRUE(all.equal(state,state2))){
		res = TRUE
	}

	return (res = res)
}
generateStates <- function(omics,algs,drugs) {
	all_omics <- list()
	ind = 1
		for (i in 1:length(omics)) {
			m=combn(omics,i)
			for(j in 1:ncol(m)){
				all_omics[[ind]] <- unlist( m[,j])
				ind = ind+1
			}

		}
	all_algs <- list()
	ind = 1
		for (i in 1:length(algs)) {
			m=combn(algs,i)
			for(j in 1:ncol(m)){
				all_algs[[ind]] <- unlist( m[,j])
				ind = ind+1
			}

		}


	all_algs[[ind]] = ""
	#generate states list
	mlist <- list (all_omics, drugs,all_algs)
	states = expand.grid(mlist)
	n_states = nrow(states)

	states_names = NULL
	for (i in 1:n_states)
	  states_names[i] = paste(unlist(states[i,]), collapse=" - ")

	return (list(states=states, n_states=n_states, all_omics= all_omics, all_algs = all_algs, states_names= states_names))
}
#function to generate all possible action
#input vector containing all algorithm names
#output : actions number; actions as str
generateActions <- function(algs) {

  nbPositions=length(algs)
  list_algs <- list()
  positions= c(1:nbPositions)

  #generate all possible actions
  #mlist <- list (algs,positions)
  mlist <- list (algs)
  actions_table = expand.grid(mlist)
  n_actions = nrow(actions_table)

  actions_str = NULL
  for (i in 1:n_actions)
    actions_str[i] = paste("put( ;",actions_table[i,1],"; )" )
  return (list(actions_str=actions_str, n_actions=n_actions))

}
#function that returns the immediate reward
#input: state; action
#output: reward r
compute_mmediate_reward <- function(state, action) {

  r=0
  omic_str = strsplit(state, "[0-9]+")[[1]][1]#e.g. "GE - ME - RPPA - "
  omic_refer = unlist(strsplit(omic_str, " - "))# vector : e.g. "GE"   "ME"   "RPPA"

  algs_str = strsplit(state, "[0-9]+")[[1]][2]#e.g. " - MKL - IntegratedMRF - srmf"
  algs_refer = unlist(strsplit(algs_str, " - "))[-1]#x_t list of alg at step t; vector; ""  "MKL" "IntegratedMRF" "srmf"
  drug_i = as.numeric(strsplit(state, "\\D+")[[1]][-1]) # requested drug e.g. 3
  selected_alg = strsplit(action, " ; ")[[1]][2] #e.g. "IntegratedMRF"
 if (!(selected_alg %in% algs_refer)) r=-2
  else
    {
      prediction_eval= compute_prediction_score(selected_alg, drugs , omic_refer,drug_i, cell_i)
      prediction_score = prediction_eval$prediction_score
      if (is.na(prediction_score ))
             r=0
      else if(prediction_score ==0)
              r=-1
            else r=1
    }
  return (r=r)
}

