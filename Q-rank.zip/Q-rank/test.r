source("RL_using_package.R")
source('globalFunctions.R')
library(cluster)
library(openxlsx)
library(ReinforcementLearning)
# Load data set
dataViews= loadDream7Data(dataLocation = 'nci_dream/')
PreclinicalGI_raw=dataViews[[1]]
testfiles=list.files("nci_dream/")
testFile = testfiles[grep('test_data.txt',testfiles)]
testdata=as.matrix(read.table(paste0("nci_dream/",testFile), header=T, row.names=1))
OCelllineNames=rownames(PreclinicalGI_raw[36:53,])
PreclinicalGI_raw[36:53,] = preprocessData(testdata, OCelllineNames)
#PreclinicalGI = PreclinicalGI_raw/9.833
Preclinical_clustred = pam_cluster(PreclinicalGI)
#  runAlgorithm (Alg_NAME,omic_ref,indiceD,cell_i) returns sensitivity of "cell_i" to drug "indiceD" using  the algorithm  Alg_NAME
#(list(predicted=predicted, clustredPred=clustredPred, PC_test=PC_test , clustredTest=clustredPC_test))
#define globale varibles
# drugs: vector of drugs
#algs = vector of algorithms
#  omics_ref (i.e., OC vector of all omics)
res_actions = generateActions(algs)
actions=res_actions$actions_str
res_g_states = generateStates(omics_ref,algs,drugs)
states =  res_g_states$states
states_names = res_g_states$states_names
all_algs = res_g_states$all_algs
all_omics = res_g_states$all_omics
n_states = res_g_states$n_states
n_drugs = length(drugs)
n_actions = res_actions$n_actions # number of actions
start_states = states_names[grep("MKL - IntegratedMRF - SRMF", states_names)]

# Get Optimal policy
Lmodel=NULL
policyOpt = Q_rank_Policy_search(nb_episodes = 1000, nb_iter =1000, statesE =states_names, Lmodel=Lmodel)

