# compare function  of 2 matrices:
#- drug responses  preclinical of test data matrice already clustred [clustredTest]
#- prediction result of a given algorithm already clustred[clustredPred_ALG_NAME]
# for the given  algorithm, this function return a reward matrice of dimention (n_test_cell, n_drug) caleld REWARD_MATRIX
# REWARD_MATRIX [i,j] = NA if   clustredTest[i,j] = NA
# REWARD_MATRIX [i,j] = 1 if   clustredPred_ALG_NAME [i,j] = clustredTest[i,j
# REWARD_MATRIX [i,j] = 0 if   clustredPred_ALG_NAME [i,j] != clustredTest[i,j]
source("RL4PRED/runMRF.R")
source("RL4PRED/mkl/runMKL.R")
#return 1 if TP or TN
#return 0 if FP or FN or NA predicted
#return NA if no realSR registered
compare_sensitivity <- function (realSR, predictedSR){

  if (!is.na(realSR )){
      if(is.na(predictedSR ))
        score = 0
      else{ if(isTRUE(predictedSR == realSR) )
              score = 1
            else  score = 0
      }
  }
  else score = NA
  return (score =score)
}
#change name from compute_reward
compute_scores_SR <- function(clustredTest,clustredPred_ALG_NAME){
  REWARD_MATRIX <- matrix(1, nrow=nrow(clustredTest),ncol=ncol(clustredTest),dimnames=list(rownames(clustredTest),colnames(clustredTest)))

		if (!isTRUE(all.equal(clustredTest,clustredPred_ALG_NAME))){
			for(i in 1:nrow(clustredTest))
						for (j in  1:ncol(clustredTest))
										REWARD_MATRIX [i,j] = compare_sensitivity(clustredTest[i,j], clustredPred_ALG_NAME[i,j])$score
		}
	reward_per_drug <- matrix(0, nrow=ncol(clustredTest),ncol=1)

	
	return (list(REWARD_MATRIX= REWARD_MATRIX)
}


#get the reward for the given algorithm
#omics_ref represent a vector of all omic data available to test:
#"GE" for GeneExpression
#"CNV" for copy number variation
# "ME" for Methylation
#"RNAe" for RNASeq_exp
#"RNAq" for RNASeq_quant
#"EX" for ExomeSeq
#"EXb" for ExomeSeq.binary
#"RPPA" for protein

compute_prediction_score <- function(Alg_NAME, drugs_list , omic_ref,indiceD,cell_i){
  if ( Alg_NAME == "IntegratedMRF"){
		#runAlgorithm() is a function that runs the corresponding algoroithm to get the predicted sensitivity
		resultAlgorithm= runAlgorithm (Alg_NAME,omic_ref,indiceD,cell_i)
		prediction_score = compare_sensitivity(resultAlgorithm$Preclinical_test_clustred, resultAlgorithm$clustredPred)
		#res_mat(1 TR, 0 FR, ..),TP, TN,FP,FN,NA, accuracy for test cells
		comp_res=comp(matrix(resultAlgorithm$clustredPred,nrow=1),matrix(resultAlgorithm$Preclinical_test_clustred,nrow=1))
    ff=list (alg = Alg_NAME, state = paste(paste(omic_ref, collapse=' '),indiceD),Pred= resultAlgorithm$predicted, PCC_test = resultAlgorithm$Preclinical_test_clustred,comp_res=comp_res)
  }
 
  cat("comparing... for", ff$alg ,"  ,", ff$state ,"  ,", comp_res$accuracy,"\n" )
  #log_table[[indice_tab]] <<- ff
 # indice_tab <<- indice_tab+1
  return (list(prediction_score = prediction_score ,comp_res=comp_res))
}




