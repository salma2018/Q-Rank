
source('RL4PRED/rl.r')

Q_rank_Policy_search <- function( parameters= list(alpha = 0.1, gamma = 0.5, epsilon = 0.1),nb_episodes, nb_iter, NB_iter_experience_replay=1, statesE, Lmodel=NULL){
	indice_iter=1
	converged = FALSE
	while(  (indice_iter<nb_iter) || (converged == TRUE){
		indice_iter=indice_iter+1
		local_dataRL <-   sampleExperience(N = nb_episodes, env = env, states = statesE, actions = actions, model = Lmodel, actionSelection = "epsilon-greedy", control = parameters)
		local_model <- ReinforcementLearning(local_dataRL, s = "State", a = "Action", r = "Reward",  s_new = "NextState",model= Lmodel, control = parameters, iter = NB_iter_experience_replay)
		converged	<- IsConverged(Lmodel,local_model)
		Lmodel=local_model
		}
	return(model= Lmodel)
}
env <- function(state, action) {
	# Calculate next state (according to chosen action)
	next_state <- state
	selected_alg = strsplit(action, " ; ")[[1]][2] 
	action_n= paste(" -", selected_alg)
	if (grepl(action_n, state )) {
		str_state <- strsplit(state, split=action_n, fixed=TRUE)
		next_state= paste(unlist(str_state), collapse="")
	}
	reward <- compute_mmediate_reward (state, action)
	return(list(NextState=next_state, Reward =reward))
}

