#####################################
###### Pairwise Distances ######
#####################################
pdist <- function(X1, X2) {
  if (identical(X1, X2) == TRUE) {
    D <- as.matrix(dist(X1))
  }
  else {
    D <- as.matrix(dist(rbind(X1, X2)))
    D <- D[1:nrow(X1), (nrow(X1) + 1):(nrow(X1) + nrow(X2))]
  }
  return(D)
}
#####################################
###### NA Functions #################
#####################################
mean.na <- function(x) { mean(na.omit(x)) }
sd.na <- function(x) { sd(na.omit(x)) }
min.na <- function(x) { min(na.omit(x)) }
max.na <- function(x) { max(na.omit(x)) }
sum.na <- function(x) { sum(na.omit(x)) }
which.na <- function(x) { which(na.omit(x)) }
length.na <- function(x) { sum(!is.na(x)) }
sort.na.dec <- function(x) { my.sort(na.omit(x),d=TRUE) }
sort.na.inc <- function(x) { my.sort(na.omit(x),d=FALSE) }
na.omit.print <- function(x) { a = na.omit(x); print(a[1:nrow(a),]) }
#####################################
###### Normalization Functions ######
#####################################
ztransform <- function(mat, FFSC,verbose=FALSE){
  cmat = ncol(mat)
  rmat = nrow(mat)
  if(cmat==1)
  {
    cm = apply(mat,2,mean.na)
    if(verbose) print(paste("Number of Z Normalized Features(COLUMNS) is:",length(cm)));
    if(sum(is.na(mat)) >= (length(mat)-1) ) cm = 0
    mat = mat - cm
    cs = apply(mat,2,sd.na)
    cs[cs == 0] = 1
    mat = mat/cs
    return(list(mat=mat,cm=cm,cs=cs))
  }
  cm = apply(mat[,FFSC:cmat],2,mean.na)
  lm = apply(mat[,FFSC:cmat],2,length.na)
  inds = which(lm==1)
  if(length(inds)>0)
    cm[inds] = 1
  if(verbose) print(paste("Number of Z Normalized Features(COLUMNS) is:",length(cm)));
  mat[,FFSC:cmat] = mat[,FFSC:cmat] - matrix(cm,rmat,(cmat-FFSC+1),byrow=TRUE)
  cs = apply(mat[,FFSC:cmat],2,sd.na)
  cs[cs == 0] = 1
  inds = which(is.na(cs))
  if(length(inds)>0)
    cs[inds] = 1
  mat[,FFSC:cmat] = mat[,FFSC:cmat]/matrix(cs,rmat,(cmat-FFSC+1),byrow=TRUE)
  return(list(mat=mat,cm=cm,cs=cs))
}
#####################################
###### Jaccard Similarity Measure (kernel for binary data) #################
#####################################
jaccard <- function(x1,x2) {
  # initialize similarity matrix
  if(isTRUE(all.equal(x1,x2))){
    m <- matrix(NA, nrow=ncol(x1),ncol=ncol(x1),dimnames=list(colnames(x1),colnames(x1)))
    tanimoto <- as.data.frame(m)

    for(i in 1:ncol(x1)) {
      for(j in i:ncol(x1)) {
        tanimoto[i,j]= length(which(x1[,i] & x1[,j])) / length(which(x1[,i] | x1[,j]))
        tanimoto[j,i]=tanimoto[i,j]
      }
    }


  }
  else{
    m <- matrix(NA, nrow=ncol(x1),ncol=ncol(x2),dimnames=list(colnames(x1),colnames(x2)))
    tanimoto <- as.data.frame(m)

    for(i in 1:ncol(x1)) {
      for(j in 1:ncol(x2)) {
        tanimoto[i,j]= length(which(x1[,i] & x2[,j])) / length(which(x1[,i] | x2[,j]))

      }
    }
  }
  return(tanimoto)
}
# compare function return a list containing matrice encoded as follow
# TP is coded as 1; TN is coded as 3 ; FP is coded as -1 ; FN is coded as -3

# matrice A is the predMat
#matrice B is the original Gi test clustered
	comp <- function(A,B){

		RES <- matrix(0, nrow=nrow(A),ncol=ncol(A),dimnames=list(rownames(A),colnames(A)))
		TP = 0
		FP = 0
		TN = 0
		FN = 0
		nb_NA = 0
		FAS = 0
		FAR = 0
		FP_A = 0
		FN_A =0
		TA = 0
	#	if (!isTRUE(all.equal(A,B))){
			for(i in 1:nrow(A))
			{
				for (j in  1:ncol(A))
				{
					if (!is.na(B[i,j] )){
						if(isTRUE(A[i,j] == 1) )
						{
							if(isTRUE(B[i,j] == 1) ){
								RES [i,j] = 1
								TP=TP+1
							}
							else{ if(isTRUE(B[i,j] == 0) ){
								RES [i,j] = -1
								FP=FP+1
							}

							}
						}
						else if(isTRUE(A[i,j] == 0) ){

							if(isTRUE(B[i,j] == 0) ){
								RES [i,j] = 3
								TN=TN+1
							}
							else{ if(isTRUE(B[i,j] == 1) ){
								RES [i,j] = -3
								FN=FN+1}

							}


						}

					} else {
						RES [i,j] = NA
						nb_NA = nb_NA +1
					}
				}
		  }
		Baccuracy = 0.5 * ((TP/(TP+FN))+(TN/(TN+FP)))
		accuracy = ((TP+TN)/(TP+FN+TN+FP))
		return (list( accuracy = accuracy, RES=RES,TP=TP,FP=FP,TN=TN,FN=FN,FAS=FAS,FAR=FAR,nb_NA=nb_NA, FP_A=FP_A, FN_A=FN_A, TA=TA))
	  }

	#CLUSTER WITH PAM
	pam_cluster <- function(original)
	{
	  #clusterd with pam then reorder the clusters to get sensitive = 1 , resistant = 3 and am =2
	  Preclinical_clustred  = NULL
	  Preclinical_clustred$mat <- matrix(NA, nrow=nrow(original),ncol=ncol(original),dimnames=list(rownames(original),colnames(original)))
	  Preclinical_clustred$mps <- matrix(NA, ncol=3, nrow=ncol(original),dimnames=list(

	    colnames(original)))
	  Preclinical_clustred$keys <- matrix(NA, ncol=2, nrow=ncol(original),dimnames=list(colnames(original)))

	  for(i in 1:ncol(original)) {
	    #read GIs for the i eme drug
	    v1= original[,i]
	    v2= original[,i]
	    #remove na
	    naV= na.omit(v1)
	    #apply pam clustering
	    s= pam(naV,3)
	    #cluter matrix
	    v1[!is.na(v1)]= s$clustering
	    # reorder cluster medoids 1, 2, 3 to much the challenge
	    m= s$medoids
	    max_cluster_ind= which.max(m)
	    min_cluster_ind= which.min(m)
	    listf = c(1,2,3)
	    m_list = c(max_cluster_ind,min_cluster_ind)
	    listf = setdiff (listf,m_list)
	    med_cluster_ind= listf[1]
	    v2[which(v1 ==  max_cluster_ind)] = 1 #high GI --> resistant
	    v2[which(v1 ==  min_cluster_ind)] = 0#3 low GI --> sensitive
	    v2[which(v1 !=  max_cluster_ind & v1 !=  min_cluster_ind )] = 1#2 inter GI --> resistant
	    Preclinical_clustred$mat[,i]=v2;
	    Preclinical_clustred$mps[i,1]=m[max_cluster_ind]
	    Preclinical_clustred$mps[i,3]=m[min_cluster_ind]
	    Preclinical_clustred$mps[i,2]=m[med_cluster_ind]
	    #calculate the point diff to cluster others cell
	    Preclinical_clustred$keys[i,1]= (Preclinical_clustred$mps[i,1] + Preclinical_clustred$mps[i,2])/2
	    Preclinical_clustred$keys[i,2]= (Preclinical_clustred$mps[i,3] + Preclinical_clustred$mps[i,2])/2
	  }
	  return (clustred = Preclinical_clustred)
	}

# CLUSTER the predicted response
 cluster_sensitivity <- function(GI_responses, cutoffs, drugs_list)
{
	#cluster the sorted pred for mrf into sensitive or resistant cells
	#predictedMRF <- matrix(as.numeric(predicted_response[,-c(1)]), nrow=N_test,ncol=length(drugs_list),dimnames=list(rownames(Y_test_GI),colnames(Y_test_GI)))
   clustred=NULL
	clustred <- matrix(NA, nrow=nrow(GI_responses) ,ncol=ncol(GI_responses),dimnames=list(rownames(GI_responses),colnames(GI_responses)))
	for (i in 1: nrow(GI_responses)) {
	  for(j in 1:ncol(GI_responses)) {
	    drug_ind = drugs_list[j]
	    if (!is.na(GI_responses[i,j])){
	      if (GI_responses[i,j] >= (cutoffs[drug_ind,1]))
	        clustred[i,j] <- 1
	      else if(GI_responses[i,j] <= cutoffs[drug_ind,2])
	        clustred[i,j] <- 0#3
	      else 			clustred[i,j] <- 1#2
	    } else clustred[i,j] = NA
	  }
	}
return (clustred = clustred)
	}
 